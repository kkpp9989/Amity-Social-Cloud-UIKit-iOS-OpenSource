//
//  AmityUIKit.h
//  AmityUIKit
//
//  Created by Nontapat Siengsanor on 17/8/2563 BE.
//  Copyright © 2563 Amity. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AmityUIKit.
FOUNDATION_EXPORT double AmityUIKitVersionNumber;

//! Project version string for AmityUIKit.
FOUNDATION_EXPORT const unsigned char AmityUIKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AmityUIKit/PublicHeader.h>


